const chalk = require("chalk")
const fs = require("fs")

//owmner v card
//domain && apikey && capikey && egg sesuai panel klian ya
// subrek channel zick official digital
global.owner = ['6287822342817'] //ur owner number
global.ownernomer = "+6281288098854" //ur owner number2
global.ownername = "KurBotz⚡" //ur owner name
global.ytname = "YT: Dittbotz" //ur yt chanel name
global.socialm = "GitHub: KurBotz" //ur github or insta name
global.location = "Indonesia" //ur location
global.codeInvite = "CswK4kvQD1u7SfSmsYfMHZ"
global.domain = 'https://pikzz.baik.pikzz.store' // isi dengan domain panel lu
global.apikey = 'ptla_anL1fxUuz3dYdzFLNrSWMPNgLsG4d4el6UFTjYEDr9Q' // Isi Apikey Plta Lu
global.capikey = 'ptlc_Glsp6ZxTCfhoAZc53FnmKqRLAVxA68eUlVh2f7VbpuN' // Isi Apikey Pltc Lu
global.eggsnya = '15' // id eggs yang dipakai
global.location = '1' // id location

//new
global.ownergc = "DittBotz"
global.botname = "bot_Ditti⚡"
global.ownerNumber = ["6287822342817@s.whatsapp.net"]
global.ownerweb = ""
global.themeemoji = '🪀'
global.wm = "panelku.xyz"
global.packname = "Sticker By"
global.author = "kurni\n\n"
global.prefa = ['','!','.','#','&']
global.sessionName = 'session'
global.tekspushkon = ''
global.keyopenai ='iigf'

global.limitawal = {
    premium: "Infinity",
    free: 5
}

//media target
global.thumb = { url: 'https://telegra.ph/file/688235e772c878933edb7.jpg' }//ur thumb pic
global.defaultpp = 'https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png?q=60' //default pp wa

//messages
global.mess = {
    selesai: 'Done !!', 
    owner: 'Khusus Owner',
    private: 'Khusus Private',
    group: 'Khusus Group',
    wait: 'Sebentar..',
}

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update'${__filename}'`))
	delete require.cache[file]
	require(file)
})
